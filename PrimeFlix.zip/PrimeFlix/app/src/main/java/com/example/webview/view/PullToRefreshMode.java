package com.example.webview.view;

public enum PullToRefreshMode {ENABLED, PROGRESS, DISABLED}
