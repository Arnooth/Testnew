package com.example.util;

public interface OnLoadMoreListener {
    void onLoadMore();
}
