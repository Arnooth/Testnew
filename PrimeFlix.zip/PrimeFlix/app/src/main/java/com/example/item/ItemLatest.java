package com.example.item;

public class ItemLatest {

    private String LatestId;
    private String LatestCategoryId;
    private String LatestCategoryName;
    private String LatestVideoUrl;
    private String LatestVideoPlayId;
    private String LatestVideoName;
    private String LatestDuration;
    private String LatestDescription;
    private String LatestImageUrl;
    private String LatestVideoType;
    private String LatestVideoImgBig;
    private String LatestVideoRate;
    private String LatestVideoView;
    private String LatestPremium;
    private String LatestResolution;

    public String getLatestId() {
        return LatestId;
    }

    public void setLatestId(String LatestId) {
        this.LatestId = LatestId;
    }

    public String getLatestCategoryId() {
        return LatestCategoryId;
    }

    public void setLatestCategoryId(String LatestCategoryId) {
        this.LatestCategoryId = LatestCategoryId;
    }

    public String getLatestCategoryName() {
        return LatestCategoryName;
    }

    public void setLatestCategoryName(String LatestCategoryName) {
        this.LatestCategoryName = LatestCategoryName;
    }

    public String getLatestVideoUrl() {
        return LatestVideoUrl;
    }

    public void setLatestVideoUrl(String LatestVideoUrl) {
        this.LatestVideoUrl = LatestVideoUrl;
    }

    public String getLatestVideoPlayId() {
        return LatestVideoPlayId;
    }

    public void setLatestVideoPlayId(String LatestVideoPlayId) {
        this.LatestVideoPlayId = LatestVideoPlayId;
    }

    public String getLatestVideoName() {
        return LatestVideoName;
    }

    public void setLatestVideoName(String LatestVideoName) {
        this.LatestVideoName = LatestVideoName;
    }

    public String getLatestDuration() {
        return LatestDuration;
    }

    public void setLatestDuration(String LatestDuration) {
        this.LatestDuration = LatestDuration;
    }

    public String getLatestDescription() {
        return LatestDescription;
    }

    public void setLatestDescription(String LatestDescription) {
        this.LatestDescription = LatestDescription;
    }

    public String getLatestImageUrl() {
        return LatestImageUrl;
    }

    public void setLatestImageUrl(String LatestImageUrl) {
        this.LatestImageUrl = LatestImageUrl;
    }

    public String getLatestVideoType() {
        return LatestVideoType;
    }

    public void setLatestVideoType(String LatestVideoType) {
        this.LatestVideoType = LatestVideoType;
    }

    public String getLatestVideoImgBig() {
        return LatestVideoImgBig;
    }

    public void setLatestVideoImgBig(String LatestVideoImgBig) {
        this.LatestVideoImgBig = LatestVideoImgBig;
    }

    public String getLatestVideoRate() {
        return LatestVideoRate;
    }

    public void setLatestVideoRate(String LatestVideoRate) {
        this.LatestVideoRate = LatestVideoRate;
    }

    public String getLatestVideoView() {
        return LatestVideoView;
    }

    public void setLatestVideoView(String LatestVideoView) {
        this.LatestVideoView = LatestVideoView;
    }

    public String getLatestPremium() {
        return LatestPremium;
    }

    public void setLatestPremium(String latestPremium) {
        LatestPremium = latestPremium;
    }

    public String getLatestResolution() {
        return LatestResolution;
    }

    public void setLatestResolution(String latestResolution) {
        LatestResolution = latestResolution;
    }
}
