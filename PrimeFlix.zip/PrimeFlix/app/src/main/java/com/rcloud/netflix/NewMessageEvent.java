package com.rcloud.netflix;

public class NewMessageEvent {

    public final int number;

    public NewMessageEvent(int number) {
        this.number = number;
    }
}
